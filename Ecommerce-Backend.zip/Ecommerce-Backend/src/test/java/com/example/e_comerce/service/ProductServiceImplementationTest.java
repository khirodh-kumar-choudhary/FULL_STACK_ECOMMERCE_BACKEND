package com.example.e_comerce.service;
 
import com.example.e_comerce.exception.ProductException;
import com.example.e_comerce.model.Category;
import com.example.e_comerce.model.Product;
import com.example.e_comerce.model.Size;
import com.example.e_comerce.repository.CategoryRepository;
import com.example.e_comerce.repository.ProductRepository;
import com.example.e_comerce.request.CreateProductRequest;
import com.example.e_comerce.response.ProductResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import java.util.*;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
class ProductServiceImplementationTest {
 
    @Mock
    private ProductRepository productRepository;
 
    @Mock
    private CategoryRepository categoryRepository;
 
    @Mock
    private UserService userService;
    @Mock
    private CreateProductRequest request;
 
    @InjectMocks
    private ProductServiceImplementation productService;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
 
    @Test
    void testCreateProduct_Success() {
        CreateProductRequest request = new CreateProductRequest();
        request.setTitle("T-Shirt");
        request.setDescription("Cotton round-neck T-Shirt");
        request.setPrice(799);
        request.setDicountedPrice(699);
        request.setDicountPercent(12);
        request.setBrand("FashionCo");
        request.setColor("Black");
        request.setSize(Set.of(new Size("M", 10)));
        request.setImageUrl("http://image.example.com/tshirt.jpg");
        request.setQuantity(10);
        request.setCategoryName("Men");
 
        Category category = new Category();
        category.setId(1L);
        category.setName("Men");
 
        when(categoryRepository.findByNameIgnoreCase("Men")).thenReturn(List.of(category));
        when(productRepository.save(any(Product.class))).thenAnswer(invocation -> invocation.getArgument(0));
 
        ProductResponse response = productService.createProduct(request);
 
        assertNotNull(response);
        assertEquals("T-Shirt", response.getTitle());
        assertEquals("Men", response.getCategoryName());
    }
 
 
    @Test
    void testDeleteProduct_NotFound() {
        when(productRepository.findById(1L)).thenReturn(Optional.empty());
 
        assertThrows(ProductException.class, () -> productService.deleteProduct(1L));
    }
 
    @Test
    void testUpdateProduct_Success() throws ProductException {
        Product existing = new Product();
        existing.setId(1L);
        existing.setQuantity(5);
 
        Product update = new Product();
        update.setQuantity(15);
 
        when(productRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(productRepository.save(any())).thenReturn(existing);
 
        Product result = productService.updateProduct(1L, update);
 
        assertEquals(15, result.getQuantity());
    }
 
    @Test
    void testUpdateProduct_NotFound() {
        when(productRepository.findById(1L)).thenReturn(Optional.empty());
 
        Product update = new Product();
        update.setQuantity(15);
 
        assertThrows(ProductException.class, () -> productService.updateProduct(1L, update));
    }
}