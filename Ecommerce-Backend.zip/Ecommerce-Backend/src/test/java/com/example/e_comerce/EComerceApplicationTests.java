package com.example.e_comerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EComerceApplicationTests {

    @Test
    void contextLoads() {
    }

}
