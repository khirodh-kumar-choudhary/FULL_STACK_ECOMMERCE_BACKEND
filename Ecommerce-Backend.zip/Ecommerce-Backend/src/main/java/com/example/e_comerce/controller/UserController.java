package com.example.e_comerce.controller;

import com.example.e_comerce.exception.UserException;
import com.example.e_comerce.model.User;
import com.example.e_comerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Get user profile using JWT
    @GetMapping("/profile")
    public ResponseEntity<User> getUserProfile(@RequestHeader("Authorization") String jwt) throws UserException {
        System.out.println("/api/users/profile");
        User user = userService.findUserProfileByJwt(jwt);
        return new ResponseEntity<>(user, HttpStatus.ACCEPTED);
    }
    
    
    @PutMapping("/update")
	public ResponseEntity<User> updateUserProfile(
	 @RequestHeader("Authorization") String jwt,
	 @RequestBody User updatedUser) throws UserException {
		User user = userService.updateUserProfile(jwt, updatedUser);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}

   
}
