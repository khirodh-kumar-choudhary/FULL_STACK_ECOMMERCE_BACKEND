package com.example.e_comerce.user.domain;

public enum PaymentStatus {

    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}
