package com.example.e_comerce.service;

import com.example.e_comerce.exception.UserException;
import com.example.e_comerce.model.User;
import com.example.e_comerce.request.LoginRequest;
import com.example.e_comerce.response.AuthResponse;

public interface AuthService {
    AuthResponse registerUser(User user) throws UserException;
    AuthResponse loginUser(LoginRequest loginRequest) throws UserException;
}