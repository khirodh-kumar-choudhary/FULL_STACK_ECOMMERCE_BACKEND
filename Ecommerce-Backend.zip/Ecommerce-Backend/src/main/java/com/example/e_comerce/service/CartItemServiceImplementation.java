package com.example.e_comerce.service;

import com.example.e_comerce.exception.CartItemException;
import com.example.e_comerce.exception.UserException;
import com.example.e_comerce.model.Cart;
import com.example.e_comerce.model.CartItem;
import com.example.e_comerce.model.Product;
import com.example.e_comerce.model.User;
import com.example.e_comerce.repository.CartItemRepository;
import com.example.e_comerce.repository.CartRepository;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class CartItemServiceImplementation implements CartItemService{


	@Autowired
    private CartItemRepository cartItemRepository;
	
	@Autowired
    private UserService userService;
	
	@Autowired
    private CartRepository cartRepository;

  

    @Override
    public CartItem createCartItem(CartItem cartItem) {

if (cartItem.getSize() == null) {
			throw new IllegalArgumentException("Size must be selected before adding to cart.");
 }

        cartItem.setQuantity(1);
        cartItem.setPrice(cartItem.getProduct().getPrice()*cartItem.getQuantity());
        cartItem.setDiscountedPrice(cartItem.getProduct().getDiscountedPrice()*cartItem.getQuantity());
        CartItem createdCartItem=(CartItem)this.cartItemRepository.save(cartItem);
        log.info("Cart Item created successfully");
        return createdCartItem;
    }

    @Override
    public CartItem updateCartItem(Long userId, Long id, CartItem cartItem) throws CartItemException, UserException {
        CartItem item=findCartItemById(id);
        User user=userService.findUserById(item.getUserId());

        if(user.getId().equals(userId)){
            item.setQuantity((cartItem.getQuantity()));
            item.setPrice(item.getQuantity()*item.getProduct().getPrice());
            item.setDiscountedPrice(item.getProduct().getDiscountedPrice()*item.getQuantity());
            
            log.info("CartItem Updated successfully");
            return (CartItem)this.cartItemRepository.save(item);
        }else
            throw new CartItemException("You can't update  another users cart item");
    }

    @Override
    public CartItem isCartItemExist(Cart cart, Product product, String size, Long userId) {
        CartItem cartItem=cartItemRepository.isCartItemExist(cart,product,size,userId);
        return cartItem;
    }

    @Override
    public void removeCartItem(Long userId, Long cartItemId) throws CartItemException, UserException {
        CartItem cartItem=this.findCartItemById(cartItemId);
        User user=this.userService.findUserById(cartItem.getUserId());
        User reqUser=this.userService.findUserById(userId);
        if (user.getId().equals(reqUser.getId())) {
            this.cartItemRepository.deleteById(cartItemId);
        }else {
            throw new UserException("You Cant Remove Another Users Item");
        }
    }

    @Override
    public CartItem findCartItemById(Long cartItemId) throws CartItemException {
        Optional<CartItem> opt=this.cartItemRepository.findById(cartItemId);
        if (opt.isPresent()){
            return (CartItem) opt.get();
        }
        throw new CartItemException("Cart Item Not Found With ID:" +cartItemId);
    }

    @Override
    public int getCartItemCount(Long userId) {
        return cartItemRepository.countByUserId(userId);
    }
}
