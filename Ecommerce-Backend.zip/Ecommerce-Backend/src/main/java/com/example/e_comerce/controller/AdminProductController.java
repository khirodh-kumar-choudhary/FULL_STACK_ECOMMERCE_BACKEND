package com.example.e_comerce.controller;

import com.example.e_comerce.exception.ProductException;
import com.example.e_comerce.model.Product;
import com.example.e_comerce.request.CreateProductRequest;
import com.example.e_comerce.response.ApiResponse;
import com.example.e_comerce.response.ProductResponse;
import com.example.e_comerce.service.ProductService;
import jakarta.validation.Valid; // Import this
import org.springframework.beans.factory.annotation.Autowired; // Import this
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/products")
public class AdminProductController {

	@Autowired
    private ProductService productService;

 

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/")
    public ResponseEntity<ProductResponse> createProductHandler(@Valid @RequestBody CreateProductRequest req) throws ProductException {
        ProductResponse createdProduct = productService.createProduct(req);
        return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{productId}/delete")
    public ResponseEntity<ApiResponse> deleteProductHandler(@PathVariable Long productId) throws ProductException {
       
        String msg = productService.deleteProduct(productId);
     
        ApiResponse res = new ApiResponse(msg, true);
        return new ResponseEntity<ApiResponse>(res, HttpStatus.ACCEPTED);
    }

    
    @GetMapping("/all")
    public ResponseEntity<List<Product>> findAllProduct() {
        List<Product> products = productService.getAllProducts();
        return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
    }



    
    
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{productId}/update")
    public ResponseEntity<Product> updateProductHandler(@RequestBody Product req, @PathVariable Long productId) throws ProductException {
        Product updatedProduct = productService.updateProduct(productId, req);
        return new ResponseEntity<Product>(updatedProduct, HttpStatus.OK);
    }
    
    @GetMapping("/category/{categoryName}")
    public ResponseEntity<List<ProductResponse>> getProductsByCategory(@PathVariable String categoryName) {
        List<Product> products = productService.findProductByCategory(categoryName.toLowerCase());

        if (products.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        List<ProductResponse> responseList = products.stream()
            .map(product -> {
                ProductResponse res = new ProductResponse();
                res.setId(product.getId());
                res.setTitle(product.getTitle());
                res.setDescription(product.getDescription());
                res.setPrice(product.getPrice());
                res.setDiscountedPrice(product.getDiscountedPrice());
                res.setDiscountedPercent(product.getDiscountedPercent());
                res.setBrand(product.getBrand());
                res.setColor(product.getColor());
                res.setSizes(product.getSizes());
                res.setImageUrl(product.getImageUrl());
                res.setQuantity(product.getQuantity());
                res.setCreatedAt(product.getCreatedAt());
                if (product.getCategory() != null) {
                    res.setCategoryName(product.getCategory().getName());
                }
                return res;
            })
            .toList();

        return new ResponseEntity<>(responseList, HttpStatus.OK);
    }

}



    
    
    

