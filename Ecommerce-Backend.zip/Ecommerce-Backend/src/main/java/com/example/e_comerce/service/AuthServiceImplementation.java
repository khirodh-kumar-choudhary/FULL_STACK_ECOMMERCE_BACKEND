package com.example.e_comerce.service;

import com.example.e_comerce.config.JwtProvider;
import com.example.e_comerce.exception.UserException;
import com.example.e_comerce.model.Address;
import com.example.e_comerce.model.User;
import com.example.e_comerce.repository.UserRepository;
import com.example.e_comerce.request.LoginRequest;
import com.example.e_comerce.response.AuthResponse;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Import for transactional operations

@Service
public class AuthServiceImplementation implements AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtProvider jwtProvider;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private CustomUserServiceImplementation customUserServiceImplementation;

    @Autowired
    private CartService cartService;

    @Override
    @Transactional 
    public AuthResponse registerUser(User user) throws UserException {
        String email = user.getEmail();
        String role = user.getRole();

     
        if (userRepository.findByEmail(email) != null) {
            throw new UserException("Email is already used with another account");
        }

        if (role != null && !role.equalsIgnoreCase("admin") && !role.equalsIgnoreCase("user")) {
            throw new UserException("Invalid role specified. Allowed roles: admin, user");
        }

       
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(role != null && role.equalsIgnoreCase("admin") ? "admin" : "user");  //  set default role
        user.setCreatedAt(LocalDateTime.now());

     
        List<Address> addresses = user.getAddress();
        user.setAddress(null);


        User savedUser = userRepository.save(user);

        // Link addresses 
        if (addresses != null && !addresses.isEmpty()) {
            for (Address address : addresses) {
                address.setUser(savedUser);
            }
            savedUser.setAddress(addresses);
            userRepository.save(savedUser); 
        }


        cartService.createCart(savedUser);

   
        String token = jwtProvider.generateToken(savedUser);

        AuthResponse authResponse = new AuthResponse();
        authResponse.setJwt(token);
        authResponse.setMessage("SignUp Success");

        return authResponse;
    }

    @Override
    public AuthResponse loginUser(LoginRequest loginRequest) throws UserException {
        String email = loginRequest.getEmail();
        String password = loginRequest.getPassword();

        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new UserException("User not found with email: " + email);
        }

        try {
            Authentication authentication = authenticate(email, password);
            SecurityContextHolder.getContext().setAuthentication(authentication);

            String token = jwtProvider.generateToken(user);

            AuthResponse authResponse = new AuthResponse();
            authResponse.setJwt(token);
            authResponse.setMessage("SignIn Success");
            return authResponse;
        } catch (BadCredentialsException e) {
            throw new UserException("Invalid credentials");
        }
    }

    // Authentication 
    private Authentication authenticate(String username, String password) {
        UserDetails userDetails = customUserServiceImplementation.loadUserByUsername(username);
        if (userDetails == null || !passwordEncoder.matches(password, userDetails.getPassword())) {
            throw new BadCredentialsException("Invalid username or password");
        }
        return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
    }
}