package com.example.e_comerce.config;

public class JwtConstant {
    public static final String SECRET_KEY="wpembytrwcvnryxksdbqwjebruyGHyudqgwveytrtrCSnwifoesarjbwe"; // Securely signin and verify JWT
    public  static final String JWT_HEADER="Authorization";
    public JwtConstant() {
    }
}
