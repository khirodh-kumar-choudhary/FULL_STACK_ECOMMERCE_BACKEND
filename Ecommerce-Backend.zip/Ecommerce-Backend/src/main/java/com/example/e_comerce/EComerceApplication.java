package com.example.e_comerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootApplication
@EnableWebMvc
public class EComerceApplication {

    public static void main(String[] args) {
        SpringApplication.run(EComerceApplication.class, args);
    	System.out.println("App running successfully at port : 1010");
    }

}
