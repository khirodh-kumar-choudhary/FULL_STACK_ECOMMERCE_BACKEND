package com.example.e_comerce.service;

import com.example.e_comerce.exception.ProductException;
import com.example.e_comerce.exception.UserException;
import com.example.e_comerce.model.Cart;
import com.example.e_comerce.model.CartItem;
import com.example.e_comerce.model.Product;
import com.example.e_comerce.model.User;
import com.example.e_comerce.repository.CartRepository;
import com.example.e_comerce.request.AddItemRequest;

import lombok.extern.slf4j.Slf4j;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class CartServiceImplementation implements CartService {

	@Autowired
    private CartRepository cartRepository;
	
	@Autowired
    private CartItemService cartItemService;
	
	@Autowired
    private ProductService productService;
	
	@Autowired
	private UserService userService;

 
    
    @Override
    public void clearCart(Cart cart) {
        cart.getCartItems().clear();
        cart.setTotalItem(0);
        cart.setTotalPrice(0.0);
        cart.setTotalDiscountedPrice(0);
        cart.setDiscount(0);

        cartRepository.save(cart);
    }


    @Override
    public Cart createCart(User user) {
        Cart cart=new Cart();
        cart.setUser(user);

        return cartRepository.save(cart);
    }

    @Override
    public CartItem addCartItem(Long userID, AddItemRequest req) throws ProductException {
        Cart cart=cartRepository.findByUserId(userID);
        Product product=productService.findProductById(req.getProductId());

        CartItem isPresent=cartItemService.isCartItemExist(cart,product, req.getSize() ,userID);
        if (isPresent==null){
            CartItem cartItem=new CartItem();
            cartItem.setProduct(product);
            cartItem.setCart(cart);
            cartItem.setQuantity(req.getQuantity());
            cartItem.setUserId(userID);

            int price= req.getQuantity()* product.getDiscountedPrice();
            cartItem.setPrice(price);
            cartItem.setSize(req.getSize());

            CartItem createdCartItem=cartItemService.createCartItem(cartItem);
            cart.getCartItems().add(createdCartItem);
            log.info("Cart created successfully");
            return createdCartItem;
        }
		return isPresent;



    }

    @Override
    public Cart findUserCart(Long userId) throws UserException {
        Cart cart = cartRepository.findByUserId(userId);

        // If cart doesn't exist, create a new one
        if (cart == null) {
            cart = new Cart();
            User user = userService.findUserById(userId); // Use full user object
            cart.setUser(user);
            cart.setCartItems(new HashSet<>());
            cart.setTotalItem(0);
            cart.setTotalPrice(0.0);
            cart.setTotalDiscountedPrice(0);
            cart.setDiscount(0);
            return cartRepository.save(cart);
        }

        // If cart is empty, set default values
        if (cart.getCartItems() == null || cart.getCartItems().isEmpty()) {
            cart.setTotalItem(0);
            cart.setTotalPrice(0.0);
            cart.setTotalDiscountedPrice(0);
            cart.setDiscount(0);
            return cart;
        }

        // Calculate totals
        int totalPrice = 0;
        int totalDiscountedPrice = 0;
        int totalItem = 0;

        for (CartItem cartItem : cart.getCartItems()) {
            totalPrice += cartItem.getPrice();
            totalDiscountedPrice += cartItem.getDiscountedPrice();
            totalItem += cartItem.getQuantity();
        }

        cart.setTotalPrice(totalPrice);
        cart.setTotalDiscountedPrice(totalDiscountedPrice);
        cart.setTotalItem(totalItem);
        cart.setDiscount(totalPrice - totalDiscountedPrice);

        return cartRepository.save(cart);
    }


    
}
