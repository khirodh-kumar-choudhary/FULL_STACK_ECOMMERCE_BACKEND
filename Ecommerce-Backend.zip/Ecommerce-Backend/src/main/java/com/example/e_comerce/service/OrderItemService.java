package com.example.e_comerce.service;

import com.example.e_comerce.model.OrderItem;

public interface OrderItemService {
    public OrderItem createOrderItem(OrderItem orderItem);
}
