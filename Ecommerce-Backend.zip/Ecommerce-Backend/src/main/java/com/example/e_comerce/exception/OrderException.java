package com.example.e_comerce.exception;

public class OrderException extends Exception{
    public OrderException(String message){
        super(message);
    }
}