package com.example.e_comerce.exception;

public class ProductException extends Exception {
    public ProductException(String message) {
        super(message);
    }
}
